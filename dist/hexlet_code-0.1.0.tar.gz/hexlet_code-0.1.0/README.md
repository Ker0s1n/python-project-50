### Hexlet tests and linter status:
[![Actions Status](https://github.com/Ker0s1n/python-project-50/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/Ker0s1n/python-project-50/actions)
### My tests and linter status:
[![check tests and linter](https://github.com/Ker0s1n/python-project-50/actions/workflows/tests-check.yml/badge.svg)](https://github.com/Ker0s1n/python-project-50/actions/workflows/tests-check.yml)
### Code_climate_checker:
[![code_climate_checker](https://github.com/Ker0s1n/python-project-50/actions/workflows/code-climate.yml/badge.svg)](https://github.com/Ker0s1n/python-project-50/actions/workflows/code-climate.yml)
### Codeclimate maintainability:
[![Maintainability](https://api.codeclimate.com/v1/badges/3439fd9798dc02cc73f1/maintainability)](https://codeclimate.com/github/Ker0s1n/python-project-50/maintainability)
### Codeclimate test coverage:
[![Test Coverage](https://api.codeclimate.com/v1/badges/3439fd9798dc02cc73f1/test_coverage)](https://codeclimate.com/github/Ker0s1n/python-project-50/test_coverage)
