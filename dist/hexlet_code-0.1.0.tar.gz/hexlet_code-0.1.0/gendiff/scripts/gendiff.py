import argparse

parser = argparse.ArgumentParser(
    description="""usage: gendiff [-h] [-f FORMAT] first_file second_file

Compares two configuration files and shows a difference.

positional arguments:
  first_file
  second_file

optional arguments:
  -h, --help            show this help message and exit
  -f FORMAT, --format FORMAT
                        set format of output
""")
def main():
    parse.print_help()


if __name__ == '__main__':
    main()
